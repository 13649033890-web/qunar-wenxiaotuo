"use client";

import { type ChangeEvent, useEffect, useState } from "react";
import {
  AirplaneTilt,
  ArrowsLeftRight,
  ArrowLeft,
  Article,
  BatteryMedium,
  Bed,
  Buildings,
  Camera,
  CalendarDots,
  CaretRight,
  CellSignalFull,
  ChatCircleDots,
  Check,
  ClockCounterClockwise,
  ClipboardText,
  Copy,
  DownloadSimple,
  FileArrowDown,
  House,
  ImageSquare,
  LinkSimple,
  MagnifyingGlass,
  MapTrifold,
  Microphone,
  Plus,
  PaperPlaneTilt,
  SidebarSimple,
  Sparkle,
  Ticket,
  Train,
  WifiHigh,
  UploadSimple,
  X,
} from "@phosphor-icons/react";

type View =
  | "home"
  | "normal-search"
  | "hotel-landing"
  | "xiaotuo"
  | "guide-create"
  | "guide-copy"
  | "tickets"
  | "hotels"
  | "hotel-select"
  | "hotel-compare";
type AppTab = "home" | "trips" | "service" | "world" | "profile";
type TicketType = "flight" | "train";
type HubMode = "plan" | "book" | "compare";
type HotelSource = "favorite" | "browsed" | "recommended";
type HotelContext = "ai" | "haidian";

type Hotel = {
  id: number;
  name: string;
  rating: string;
  area: string;
  price: number;
  stars: string;
  breakfast: string;
  cancellation: string;
  room: string;
  distance: string;
  highlight: string;
  imageTone: string;
  imageSrc?: string;
};

const tabAssets: Record<AppTab, string> = {
  home: "/reference/qunar-home-search-wide.png",
  trips: "/reference/qunar-trips.jpg",
  service: "/reference/qunar-service.jpg",
  world: "/reference/qunar-world.jpg",
  profile: "/reference/qunar-profile.jpg",
};

const homeServices = [
  "特价酒店",
  "民宿·客栈",
  "海外酒店",
  "酒店专区",
  "低价机票",
  "火车·高铁",
  "租车自驾",
  "接机/送机",
  "出境/国内游",
  "景点·门票",
  "跟团游",
  "借钱/分期",
];

const flowSteps: Array<{ view: View; title: string; note: string }> = [
  { view: "home", title: "去哪儿首页", note: "拉长搜索框，无独立入口" },
  { view: "normal-search", title: "搜索Tab", note: "保持去哪儿原中间页" },
  { view: "hotel-landing", title: "酒店落地页", note: "4次点击 / 停留10秒" },
  { view: "xiaotuo", title: "问小驼Tab", note: "上一版AI主页与任务" },
  { view: "guide-create", title: "做攻略", note: "填写需求后生成" },
  { view: "guide-copy", title: "抄攻略", note: "导入链接 / 图片并解析" },
  { view: "tickets", title: "订票", note: "机票 / 火车票" },
  { view: "hotels", title: "酒店PK", note: "选择酒店并横向对比" },
  { view: "hotel-select", title: "选择酒店", note: "收藏 / 浏览 / 推荐" },
  { view: "hotel-compare", title: "酒店对比", note: "生成差异表与建议" },
];

const hotelCatalog: Hotel[] = [
  {
    id: 1,
    name: "成都春熙路轻居酒店",
    rating: "4.8",
    area: "春熙路 / 太古里",
    price: 328,
    stars: "高档型",
    breakfast: "双人早餐",
    cancellation: "入住前1天可免费取消",
    room: "舒适大床房",
    distance: "步行6分钟到地铁",
    highlight: "位置和早餐综合表现更均衡",
    imageTone: "mint",
  },
  {
    id: 2,
    name: "成都太古里云端酒店",
    rating: "4.7",
    area: "太古里 / 望平街",
    price: 286,
    stars: "舒适型",
    breakfast: "不含早餐",
    cancellation: "当日18点前可取消",
    room: "城景大床房",
    distance: "步行9分钟到地铁",
    highlight: "预算更低，周边餐饮选择多",
    imageTone: "blue",
  },
  {
    id: 3,
    name: "成都熊猫基地漫居酒店",
    rating: "4.9",
    area: "熊猫基地 / 昭觉寺",
    price: 418,
    stars: "豪华型",
    breakfast: "双人早餐",
    cancellation: "入住前2天可免费取消",
    room: "亲子主题房",
    distance: "驾车12分钟到熊猫基地",
    highlight: "亲子设施丰富，适合家庭出行",
    imageTone: "orange",
  },
  {
    id: 4,
    name: "成都天府广场智选酒店",
    rating: "4.6",
    area: "天府广场 / 人民公园",
    price: 259,
    stars: "舒适型",
    breakfast: "单人早餐",
    cancellation: "不可取消",
    room: "标准双床房",
    distance: "步行3分钟到地铁",
    highlight: "交通方便，适合短途城市游",
    imageTone: "purple",
  },
  {
    id: 5,
    name: "成都东站悦居酒店",
    rating: "4.5",
    area: "成都东站 / 万象城",
    price: 228,
    stars: "经济型",
    breakfast: "不含早餐",
    cancellation: "入住前1天可免费取消",
    room: "悦享大床房",
    distance: "步行8分钟到成都东站",
    highlight: "适合中转或早班车行程",
    imageTone: "gold",
  },
];

const haidianHotelCatalog: Hotel[] = [
  {
    id: 1,
    name: "全季酒店（北京中关村苏州街店）",
    rating: "4.9",
    area: "中关村 / 苏州街",
    price: 567,
    stars: "舒适型",
    breakfast: "双人早餐",
    cancellation: "入住前1天可免费取消",
    room: "高级大床房",
    distance: "距区域中心直线2.1公里",
    highlight: "位置便利，服务和早餐表现均衡",
    imageTone: "mint",
    imageSrc: "/reference/haidian-hotel-1.jpg",
  },
  {
    id: 2,
    name: "秋果智选酒店（北京大学苏州街地铁站店）",
    rating: "4.9",
    area: "北京大学 / 苏州街",
    price: 457,
    stars: "舒适型",
    breakfast: "自助早餐",
    cancellation: "延迟退房，可免费取消",
    room: "智选大床房",
    distance: "距苏州街地铁站步行约6分钟",
    highlight: "交通方便，房间细节与服务评价突出",
    imageTone: "blue",
    imageSrc: "/reference/haidian-hotel-2.jpg",
  },
  {
    id: 3,
    name: "巴比伦时尚酒店（北京中关村人民大学店）",
    rating: "4.5",
    area: "人民大学 / 海淀黄庄",
    price: 305,
    stars: "经济型",
    breakfast: "不含早餐",
    cancellation: "入住当日18点前可取消",
    room: "时尚大床房",
    distance: "距区域中心直线2.1公里",
    highlight: "预算更低，适合短住和高性价比需求",
    imageTone: "orange",
    imageSrc: "/reference/haidian-hotel-3.jpg",
  },
  {
    id: 4,
    name: "漫兮酒店（北京大学苏州街地铁站店）",
    rating: "4.7",
    area: "北京大学 / 苏州街",
    price: 399,
    stars: "舒适型",
    breakfast: "单人早餐",
    cancellation: "入住前1天可免费取消",
    room: "雅致大床房",
    distance: "距苏州街地铁站步行约5分钟",
    highlight: "靠近地铁，适合北大及中关村周边行程",
    imageTone: "purple",
    imageSrc: "/reference/haidian-hotel-4.jpg",
  },
  {
    id: 5,
    name: "富驿时尚酒店（北京中关村店）",
    rating: "4.8",
    area: "中关村 / 苏州街",
    price: 374,
    stars: "经济型",
    breakfast: "不含早餐",
    cancellation: "入住前1天可免费取消",
    room: "精选大床房",
    distance: "距区域中心直线950米",
    highlight: "距离近，适合重视通勤效率的用户",
    imageTone: "gold",
  },
];

const historyItems = [
  { id: "h1", title: "对比成都春熙路附近酒店", time: "今天 12:48" },
  { id: "h2", title: "潮汕3天2晚轻松行程", time: "昨天 21:16" },
  { id: "h3", title: "周五北京飞成都低价机票", time: "8月8日" },
];

const AI_QUERY_PRESET = "9月带父母去北京玩4天，人均3000元，想住地铁附近、不走回头路，帮我规划行程并比较合适的酒店";

const aiSearchStages = [
  { title: "理解需求", detail: "识别北京、4天、父母同行、人均3000元等关键条件" },
  { title: "补全约束", detail: "将少走路、地铁便利和不走回头路转成可筛选条件" },
  { title: "检索实时信息", detail: "同时查询景点开放时间、交通距离和可订酒店" },
  { title: "统一条件比较", detail: "对齐日期、房型、早餐、含税价和退改规则" },
  { title: "生成可执行方案", detail: "按每天动线组织行程，并给出酒店取舍建议" },
];

const guideThinkingStages = [
  { title: "拆解旅行需求", detail: "提取同行人、预算、节奏与住宿偏好" },
  { title: "核对目的地信息", detail: "检查景点开放时间、区域距离与交通方式" },
  { title: "组合每日动线", detail: "减少折返，并为父母预留休息时间" },
  { title: "校验总预算", detail: "估算交通、住宿、门票和餐饮支出" },
];

function QunarCamel({ compact = false, solid = false }: { compact?: boolean; solid?: boolean }) {
  return (
    <span className={compact ? "qunar-camel compact" : "qunar-camel"} aria-hidden="true">
      <img src={solid ? "/brand/qunar-camel-solid-white.png" : "/brand/qunar-camel-outline.png"} alt="" />
    </span>
  );
}

function HotelThumb({ hotel, compare = false }: { hotel: Hotel; compare?: boolean }) {
  const className = compare
    ? `compare-hotel-image ${hotel.imageTone}${hotel.imageSrc ? " has-photo" : ""}`
    : `hotel-image-placeholder ${hotel.imageTone}${hotel.imageSrc ? " has-photo" : ""}`;
  return (
    <span className={className}>
      {hotel.imageSrc ? <img src={hotel.imageSrc} alt={`${hotel.name}实拍`} /> : <Bed size={compare ? 22 : 24} />}
      {!compare && !hotel.imageSrc && <small>酒店实拍</small>}
    </span>
  );
}

function PhoneStatus() {
  return (
    <div className="phone-status" aria-label="状态栏">
      <strong>2:13</strong>
      <div>
        <CellSignalFull size={16} weight="fill" />
        <WifiHigh size={17} weight="bold" />
        <BatteryMedium size={21} weight="fill" />
      </div>
    </div>
  );
}

function ScreenHeader({ title, subtitle, onBack }: { title: string; subtitle?: string; onBack: () => void }) {
  return (
    <header className="screen-header">
      <button type="button" onClick={onBack} aria-label="返回">
        <ArrowLeft size={22} weight="bold" />
      </button>
      <div className="screen-title">
        <strong>{title}</strong>
        {subtitle && <small>{subtitle}</small>}
      </div>
      <QunarCamel compact />
    </header>
  );
}

function SearchAiTabs({
  active,
  variant,
  onSearch,
  onAi,
}: {
  active: "search" | "ai";
  variant: "reference" | "assistant";
  onSearch: () => void;
  onAi: () => void;
}) {
  return (
    <div className={`search-ai-tabs ${variant}`} role="tablist" aria-label="搜索模式">
      <button type="button" role="tab" aria-selected={active === "search"} className={active === "search" ? "active" : ""} onClick={onSearch}>搜索</button>
      <button type="button" role="tab" aria-selected={active === "ai"} className={active === "ai" ? "active" : ""} onClick={onAi}>问小驼</button>
    </div>
  );
}

function Skeleton({ rows = 3 }: { rows?: number }) {
  return (
    <div className="skeleton-block" aria-label="内容占位">
      {Array.from({ length: rows }).map((_, index) => (
        <span key={index} className={index === rows - 1 ? "short" : ""} />
      ))}
    </div>
  );
}

function TaskDock({ active, onOpen }: { active?: "guide" | "tickets" | "hotels"; onOpen: (view: View) => void }) {
  const tasks = [
    { key: "guide", label: "做攻略", view: "guide-create" as View, icon: MapTrifold },
    { key: "hotels", label: "酒店PK", view: "hotels" as View, icon: ArrowsLeftRight },
    { key: "tickets", label: "订票", view: "tickets" as View, icon: Ticket },
  ] as const;
  return (
    <nav className="task-dock" aria-label="问小驼功能">
      {tasks.map((task) => {
        const Icon = task.icon;
        return (
          <button
            type="button"
            key={task.key}
            className={active === task.key ? "active" : ""}
            onClick={() => onOpen(task.view)}
          >
            <Icon size={23} weight={active === task.key ? "fill" : "regular"} />
            <span>{task.label}</span>
          </button>
        );
      })}
    </nav>
  );
}

export default function Home() {
  const [view, setView] = useState<View>("home");
  const [appTab, setAppTab] = useState<AppTab>("home");
  const [reviewOpen, setReviewOpen] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [activeHistory, setActiveHistory] = useState("h1");
  const [hubMode, setHubMode] = useState<HubMode>("plan");
  const [toast, setToast] = useState("");
  const [guideGenerated, setGuideGenerated] = useState(false);
  const [guideThinkingStep, setGuideThinkingStep] = useState(-1);
  const [guidePreference, setGuidePreference] = useState("");
  const [guideVoiceListening, setGuideVoiceListening] = useState(false);
  const [linkValue, setLinkValue] = useState("");
  const [linkParsed, setLinkParsed] = useState(false);
  const [uploadedGuideName, setUploadedGuideName] = useState("");
  const [uploadedGuidePreview, setUploadedGuidePreview] = useState("");
  const [imageParsed, setImageParsed] = useState(false);
  const [aiQuery, setAiQuery] = useState(AI_QUERY_PRESET);
  const [aiDemoStep, setAiDemoStep] = useState(-1);
  const [ticketType, setTicketType] = useState<TicketType>("flight");
  const [ticketSearched, setTicketSearched] = useState(false);
  const [hotelSearched, setHotelSearched] = useState(false);
  const [hotelSource, setHotelSource] = useState<HotelSource>("favorite");
  const [selectedHotels, setSelectedHotels] = useState<number[]>([]);
  const [hotelContext, setHotelContext] = useState<HotelContext>("ai");
  const [landingViewedHotels, setLandingViewedHotels] = useState<number[]>([]);
  const [compareNudgeVisible, setCompareNudgeVisible] = useState(false);

  useEffect(() => {
    const assets = [
      ...Object.values(tabAssets),
      "/reference/qunar-current-search.png",
      "/reference/qunar-haidian-sug.jpg",
      "/reference/qunar-haidian-hotels.jpg",
      "/brand/qunar-home-entry-clean-patch.png",
      "/brand/qunar-camel-solid-white.png",
      ...haidianHotelCatalog.flatMap((hotel) => hotel.imageSrc ? [hotel.imageSrc] : []),
    ];
    assets.forEach((src) => {
      const image = new Image();
      image.src = src;
    });
  }, []);

  useEffect(() => {
    if (view !== "hotel-landing") return;
    const timer = window.setTimeout(() => setCompareNudgeVisible(true), 10_000);
    return () => window.clearTimeout(timer);
  }, [view]);

  useEffect(() => {
    if (view !== "xiaotuo" || aiDemoStep < 0 || aiDemoStep >= aiSearchStages.length) return;
    const timer = window.setTimeout(() => setAiDemoStep((current) => current + 1), 920);
    return () => window.clearTimeout(timer);
  }, [aiDemoStep, view]);

  useEffect(() => {
    if (view !== "guide-create" || !guideGenerated || guideThinkingStep < 0 || guideThinkingStep >= guideThinkingStages.length) return;
    const timer = window.setTimeout(() => setGuideThinkingStep((current) => current + 1), 720);
    return () => window.clearTimeout(timer);
  }, [guideGenerated, guideThinkingStep, view]);

  const notify = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(""), 1800);
  };

  const openView = (nextView: View) => {
    setHistoryOpen(false);
    setToast("");
    setView(nextView);
    if (nextView === "home") setAppTab("home");
    if (nextView === "hotels") setHotelContext("ai");
  };

  const openSearchGateway = () => {
    setHistoryOpen(false);
    setToast("");
    setView("normal-search");
  };

  const resetTaskResults = () => {
    setGuideGenerated(false);
    setGuideThinkingStep(-1);
    setGuideVoiceListening(false);
    setLinkParsed(false);
    setImageParsed(false);
    setTicketSearched(false);
    setHotelSearched(false);
  };

  const returnToXiaotuo = () => {
    resetTaskResults();
    setAiDemoStep(-1);
    setHistoryOpen(false);
    setToast("");
    setView("xiaotuo");
  };

  const openXiaotuoTask = (nextView: View) => {
    resetTaskResults();
    if (nextView === "hotels" || nextView === "hotel-select" || nextView === "hotel-compare") {
      setHotelContext("ai");
    }
    if (nextView === "hotels") setSelectedHotels([]);
    if (nextView === "hotel-compare") {
      setSelectedHotels((current) => current.length >= 2 ? current : [1, 2]);
    }
    setHistoryOpen(false);
    setToast("");
    setView(nextView);
  };

  const openAppTab = (tab: AppTab) => {
    setHistoryOpen(false);
    setToast("");
    setAppTab(tab);
    setView("home");
  };

  const activeFlow = view;

  const openHotelLanding = () => {
    setHistoryOpen(false);
    setToast("");
    setHotelContext("haidian");
    setLandingViewedHotels([]);
    setCompareNudgeVisible(false);
    setView("hotel-landing");
  };

  const registerLandingHotelView = (id: number) => {
    setLandingViewedHotels((current) => {
      if (current.includes(id)) {
        notify(`已查看 ${current.length} 家酒店`);
        return current;
      }
      const next = [...current, id];
      if (next.length > 3) setCompareNudgeVisible(true);
      notify(`已查看 ${next.length} 家酒店`);
      return next;
    });
  };

  const openLandingCompare = () => {
    setHistoryOpen(false);
    setToast("");
    setHotelContext("haidian");
    setHotelSource("browsed");
    setSelectedHotels(landingViewedHotels.length >= 2 ? landingViewedHotels.slice(0, 5) : [1, 2]);
    setView("hotel-select");
  };

  const screenshotTabs = () => (
    <nav className="screenshot-tab-hotspots" aria-label="去哪儿原底部导航">
      {(["home", "trips", "service", "world", "profile"] as AppTab[]).map((tab) => (
        <button
          key={tab}
          type="button"
          aria-label={`打开${tab}页面`}
          onClick={() => {
            openAppTab(tab);
          }}
        />
      ))}
    </nav>
  );

  const renderOriginalHome = () => {
    if (appTab !== "home") {
      return (
        <div className="original-app-screen">
          <img src={tabAssets[appTab]} alt="去哪儿App原页面" className="original-screen-image" />
          <button className="original-page-hotspot" type="button" onClick={() => notify("已响应；该页面沿用去哪儿原有交互")} aria-label="原页面内容区域" />
          {screenshotTabs()}
        </div>
      );
    }

    return (
      <div className="original-app-screen">
        <img src={tabAssets.home} alt="去哪儿App首页原页面" className="original-screen-image" />
        <button className="home-search-hotspot" type="button" onClick={openSearchGateway} aria-label="打开搜索与问小驼" />
        <div className="service-hotspots" aria-label="首页业务入口">
          {homeServices.map((service) => (
            <button type="button" key={service} onClick={() => notify(`已打开${service}`)} aria-label={service} />
          ))}
        </div>
        <button className="campaign-hotspot" type="button" onClick={() => notify("已打开首页活动")} aria-label="首页活动" />
        <div className="campaign-card-hotspots" aria-label="首页快捷活动">
          {Array.from({ length: 5 }).map((_, index) => (
            <button type="button" key={index} onClick={() => notify("已打开活动详情")} aria-label={`活动${index + 1}`} />
          ))}
        </div>
        <div className="feed-hotspots" aria-label="首页内容流">
          <button type="button" onClick={() => notify("已打开内容详情")} aria-label="左侧内容" />
          <button type="button" onClick={() => notify("已打开内容详情")} aria-label="右侧内容" />
        </div>
        {screenshotTabs()}
      </div>
    );
  };

  const renderNormalSearch = () => (
    <div className="reference-flow-screen normal-search-reference">
      <img src="/reference/qunar-current-search.png" alt="去哪儿当前搜索中间页" />
      <SearchAiTabs active="search" variant="reference" onSearch={() => undefined} onAi={returnToXiaotuo} />
      <button className="normal-search-back-hotspot" type="button" onClick={() => openView("home")} aria-label="返回首页" />
      <button className="normal-search-input-hotspot" type="button" onClick={() => notify("已聚焦普通搜索框")} aria-label="普通搜索框" />
      <button className="normal-search-submit-hotspot" type="button" onClick={openHotelLanding} aria-label="搜索和顺古镇景区" />
      <div className="normal-search-business-hotspots" aria-label="搜索业务入口">
        <button type="button" onClick={() => notify("已打开租车搜索")} aria-label="租车" />
        <button type="button" onClick={() => openXiaotuoTask("tickets")} aria-label="机票" />
        <button type="button" onClick={() => notify("已打开门票搜索")} aria-label="门票" />
        <button type="button" onClick={openHotelLanding} aria-label="酒店" />
        <button type="button" onClick={() => openXiaotuoTask("hotels")} aria-label="民宿" />
      </div>
      <button className="normal-search-history-hotspot" type="button" onClick={() => notify("已选择一条历史搜索")} aria-label="历史搜索" />
      <button className="normal-search-popular-hotspot" type="button" onClick={openHotelLanding} aria-label="热门推荐" />
      <button className="normal-search-flight-hotspot" type="button" onClick={() => openXiaotuoTask("tickets")} aria-label="特价机票" />
      <button className="normal-search-ranking-hotspot" type="button" onClick={openHotelLanding} aria-label="精选酒店榜单" />
    </div>
  );

  const renderHotelLanding = () => (
    <div className="reference-flow-screen hotel-landing-screen">
      <img src="/reference/qunar-haidian-hotels.jpg" alt="去哪儿海淀区酒店落地页" />
      <button className="landing-back-hotspot" type="button" onClick={() => openView("normal-search")} aria-label="返回搜索建议" />
      <div className="landing-hotel-hotspots" aria-label="海淀区酒店列表">
        {[1, 2, 3, 4].map((hotelId) => (
          <button
            type="button"
            key={hotelId}
            className={`landing-hotel-${hotelId}`}
            onClick={() => registerLandingHotelView(hotelId)}
            aria-label={`查看第${hotelId}家酒店`}
          />
        ))}
      </div>
      <button
        type="button"
        className={compareNudgeVisible ? "landing-compare-float visible" : "landing-compare-float"}
        onClick={openLandingCompare}
        aria-label="问小驼帮我比一比"
        tabIndex={compareNudgeVisible ? 0 : -1}
      >
        <QunarCamel compact solid />
        <strong>比一比</strong>
      </button>
    </div>
  );

  const hubSuggestions: Record<HubMode, Array<{ text: string; view: View; action?: string }>> = {
    plan: [
      { text: "3天2晚去潮汕，人均2000元，带父母，不要太赶", view: "guide-create" },
      { text: "把我收藏的外部攻略整理成一份可编辑行程", view: "guide-copy" },
      { text: "从北京出发，周末去哪里轻松又划算？", view: "guide-create" },
    ],
    book: [
      { text: "周五晚北京飞成都，800元内，不要红眼", view: "tickets" },
      { text: "上海迪士尼附近亲子酒店，含早餐，1000元以内", view: "hotels" },
      { text: "帮我把机票和酒店分开找，条件都可以继续调整", view: "tickets" },
    ],
    compare: [
      { text: "从浏览记录里选择两家酒店，比较总价和退改条件", view: "hotels" },
      { text: "先找酒店，再选择2—3家进入酒店对比", view: "hotels" },
      { text: "比较含税价格、早餐、位置和取消规则", view: "hotel-compare", action: "直接查看结构" },
    ],
  };

  const openHubSuggestion = (item: { view: View }) => {
    if (item.view === "hotel-compare" && selectedHotels.length < 2) setSelectedHotels([1, 2]);
    openXiaotuoTask(item.view);
  };

  const resetAiDemo = () => {
    setAiDemoStep(-1);
    setAiQuery(AI_QUERY_PRESET);
  };

  const startAiSearch = () => {
    if (!aiQuery.trim()) return notify("请先输入一个旅行问题");
    setHistoryOpen(false);
    setAiDemoStep(0);
  };

  const startGuideVoiceInput = () => {
    if (guideVoiceListening) return;
    setGuideVoiceListening(true);
    window.setTimeout(() => {
      setGuidePreference("人均预算3000元，带父母出行，希望每天10点左右再出门，景点之间尽量顺路，少走路、不赶早，住宿靠近地铁并含早餐，想安排一次北京特色餐，但不要连续吃太油腻的食物。");
      setGuideVoiceListening(false);
      notify("已识别并填入语音需求");
    }, 1100);
  };

  const handleGuideImage = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) return notify("请选择攻略图片");
    setUploadedGuideName(file.name);
    setImageParsed(false);
    const reader = new FileReader();
    reader.onload = () => setUploadedGuidePreview(String(reader.result || ""));
    reader.readAsDataURL(file);
  };

  const renderXiaotuoHub = () => (
    <div className="ai-screen xiaotuo-home-screen">
      <PhoneStatus />
      <section className="assistant-surface">
        <div className="assistant-topbar">
          <div className="assistant-topbar-left">
            <button type="button" onClick={() => openView("normal-search")} aria-label="返回搜索中间页"><ArrowLeft size={23} weight="bold" /></button>
            <button type="button" onClick={() => setHistoryOpen(true)} aria-label="打开历史对话"><SidebarSimple size={23} weight="bold" /></button>
          </div>
          <SearchAiTabs active="ai" variant="assistant" onSearch={() => openView("normal-search")} onAi={() => undefined} />
          <button type="button" onClick={() => { resetAiDemo(); notify("已新建一段对话"); }} aria-label="新建对话"><Plus size={24} weight="bold" /></button>
        </div>

        {aiDemoStep < 0 ? (
          <div className="assistant-content">
            <div className="assistant-identity"><QunarCamel solid /></div>
            <h1>去哪儿？问小驼</h1>

            <div className="assistant-tabs" role="tablist" aria-label="小驼服务类型">
              <button type="button" role="tab" aria-selected={hubMode === "plan"} className={hubMode === "plan" ? "active" : ""} onClick={() => setHubMode("plan")}>帮我规划</button>
              <button type="button" role="tab" aria-selected={hubMode === "book"} className={hubMode === "book" ? "active" : ""} onClick={() => setHubMode("book")}>帮我预订</button>
              <button type="button" role="tab" aria-selected={hubMode === "compare"} className={hubMode === "compare" ? "active" : ""} onClick={() => setHubMode("compare")}>帮我比较</button>
            </div>

            <div className="assistant-suggestions" aria-live="polite">
              {hubSuggestions[hubMode].map((item, index) => (
                <button type="button" key={`${hubMode}-${index}`} onClick={() => openHubSuggestion(item)}>
                  <Sparkle size={13} weight="fill" />
                  <span>{item.text}</span>
                  {item.action && <b>{item.action}<CaretRight size={15} /></b>}
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="assistant-content ai-demo-content" aria-live="polite">
            <div className="ai-demo-heading"><QunarCamel compact solid /><span><strong>小驼正在为你搜索</strong><small>实时拆解需求并核对可订信息</small></span></div>
            <div className="user-query-bubble">{aiQuery}</div>
            <section className="ai-search-process">
              {aiSearchStages.map((stage, index) => {
                const state = aiDemoStep > index ? "done" : aiDemoStep === index ? "active" : "waiting";
                return (
                  <div className={`ai-search-step ${state}`} key={stage.title}>
                    <i>{state === "done" ? <Check size={13} weight="bold" /> : index + 1}</i>
                    <span><strong>{stage.title}</strong><small>{stage.detail}</small></span>
                    {state === "active" && <b><span /><span /><span /></b>}
                  </div>
                );
              })}
            </section>
            {aiDemoStep >= aiSearchStages.length && (
              <section className="ai-answer-card">
                <div><Sparkle size={18} weight="fill" /><strong>方案已生成</strong></div>
                <p>建议前两晚住王府井或东单，后两晚住海淀，减少跨城折返；行程按“故宫片区—天坛前门—颐和园圆明园—自由活动”组织。</p>
                <ul><li>优先筛选地铁步行10分钟内、含早餐、可免费取消的酒店</li><li>酒店将按同日期、同房型和含税总价继续比较</li></ul>
                <div className="ai-answer-actions"><button type="button" onClick={() => openXiaotuoTask("guide-create")}>查看完整攻略</button><button type="button" onClick={() => openXiaotuoTask("hotels")}>酒店PK</button></div>
              </section>
            )}
          </div>
        )}

        <div className="assistant-bottom">
          <div className="assistant-shortcuts" aria-label="问小驼核心功能">
            <button type="button" onClick={() => openXiaotuoTask("guide-create")}><MapTrifold size={17} />做攻略</button>
            <button type="button" onClick={() => openXiaotuoTask("hotels")}><ArrowsLeftRight size={17} />酒店PK</button>
            <button type="button" onClick={() => openXiaotuoTask("tickets")}><Ticket size={17} />订票</button>
          </div>
          <div className="assistant-composer">
            <button type="button" onClick={() => notify("语音输入已开启")} aria-label="语音输入"><Microphone size={24} weight="bold" /></button>
            <input aria-label="向小驼发送消息" value={aiQuery} onChange={(event) => setAiQuery(event.target.value)} placeholder="发消息或按住说话…" />
            <button type="button" onClick={() => notify("已打开相机")} aria-label="拍照或上传图片"><Camera size={23} /></button>
            <button type="button" className="assistant-send" onClick={startAiSearch} aria-label="发送并开始AI搜索"><PaperPlaneTilt size={20} weight="fill" /></button>
          </div>
        </div>
      </section>
      <button
        type="button"
        className={historyOpen ? "history-scrim open" : "history-scrim"}
        onClick={() => setHistoryOpen(false)}
        aria-label="关闭历史对话"
        tabIndex={historyOpen ? 0 : -1}
      />
      <aside className={historyOpen ? "history-drawer open" : "history-drawer"} aria-hidden={!historyOpen} aria-label="历史对话">
        <div className="history-drawer-head">
          <div><QunarCamel compact solid /><strong>历史对话</strong></div>
          <button type="button" onClick={() => setHistoryOpen(false)} aria-label="关闭"><X size={21} weight="bold" /></button>
        </div>
        <button className="new-conversation" type="button" onClick={() => { setHistoryOpen(false); notify("已新建一段对话"); }}>
          <Plus size={18} weight="bold" />新对话
        </button>
        <div className="history-list">
          {historyItems.map((item) => (
            <button
              type="button"
              key={item.id}
              className={activeHistory === item.id ? "active" : ""}
              onClick={() => {
                setActiveHistory(item.id);
                setHistoryOpen(false);
                notify(`已打开：${item.title}`);
              }}
            >
              <ChatCircleDots size={19} />
              <span><strong>{item.title}</strong><small>{item.time}</small></span>
              <CaretRight size={16} />
            </button>
          ))}
        </div>
        <p><ClockCounterClockwise size={16} />历史记录仅用于原型演示</p>
      </aside>
    </div>
  );

  const GuideModeSwitch = ({ copyMode }: { copyMode: boolean }) => (
    <div className="mode-switch" role="tablist" aria-label="攻略方式">
      <button type="button" role="tab" aria-selected={!copyMode} className={!copyMode ? "active" : ""} onClick={() => openXiaotuoTask("guide-create")}>
        <Article size={18} />做攻略
      </button>
      <button type="button" role="tab" aria-selected={copyMode} className={copyMode ? "active" : ""} onClick={() => openXiaotuoTask("guide-copy")}>
        <Copy size={18} />抄攻略
      </button>
    </div>
  );

  const renderGuideCreate = () => (
    <div className="ai-screen">
      <PhoneStatus />
      <ScreenHeader title="做攻略" subtitle="按你的需求生成" onBack={returnToXiaotuo} />
      <div className="ai-scroll task-page-scroll">
        <GuideModeSwitch copyMode={false} />
        <section className="task-intro"><MapTrifold size={28} weight="duotone" /><div><strong>告诉小驼你的旅行想法</strong><small>内容区先保留结构，后续再完善生成结果</small></div></section>
        <section className="form-card">
          <label><span>目的地</span><input placeholder="例如：潮汕" /></label>
          <div className="form-grid">
            <label><span>出发日期</span><button type="button" onClick={() => notify("已打开日期选择")}><CalendarDots size={17} />选择日期</button></label>
            <label><span>游玩天数</span><button type="button" onClick={() => notify("已打开天数选择")}>3天2晚<CaretRight size={16} /></button></label>
          </div>
          <label><span>预算与偏好</span><div className="preference-voice-field"><textarea value={guidePreference} onChange={(event) => setGuidePreference(event.target.value)} placeholder="例如：人均3000元，带父母出行，每天10点左右出门；少走路、不赶早，景点尽量顺路，酒店靠近地铁并含早餐，还想安排一顿北京特色餐。" /><button type="button" className={guideVoiceListening ? "listening" : ""} onClick={startGuideVoiceInput} aria-label="语音输入预算与偏好"><Microphone size={19} weight="bold" /><small>{guideVoiceListening ? "识别中" : "语音"}</small></button></div></label>
          <button className="primary-cta" type="button" onClick={() => { setGuideGenerated(true); setGuideThinkingStep(0); }}><Sparkle size={18} weight="fill" />生成攻略</button>
        </section>
        {guideGenerated ? (
          <>
            <section className="guide-thinking-card" aria-live="polite">
              <div className="guide-thinking-title"><Sparkle size={17} weight="fill" /><span><strong>{guideThinkingStep >= guideThinkingStages.length ? "小驼已完成思考" : "小驼正在思考"}</strong><small>以下展示AI搜索生成攻略的大致过程</small></span></div>
              {guideThinkingStages.map((stage, index) => <div className={`guide-thinking-row ${guideThinkingStep > index ? "done" : guideThinkingStep === index ? "active" : "waiting"}`} key={stage.title}><i>{guideThinkingStep > index ? <Check size={12} weight="bold" /> : index + 1}</i><span><strong>{stage.title}</strong><small>{stage.detail}</small></span></div>)}
            </section>
            {guideThinkingStep >= guideThinkingStages.length && <section className="result-placeholder">
              <div className="result-state"><Check size={18} weight="bold" /><strong>攻略结构已生成</strong></div>
              <div className="day-placeholder-row">{[1, 2, 3].map((day) => <button type="button" key={day} onClick={() => notify(`已切换到第${day}天`)}>D{day}</button>)}</div>
              <Skeleton rows={5} />
            </section>}
          </>
        ) : <section className="empty-result-placeholder"><Skeleton rows={5} /></section>}
      </div>
      <TaskDock active="guide" onOpen={openXiaotuoTask} />
    </div>
  );

  const renderGuideCopy = () => (
    <div className="ai-screen">
      <PhoneStatus />
      <ScreenHeader title="抄攻略" subtitle="导入外部内容" onBack={returnToXiaotuo} />
      <div className="ai-scroll task-page-scroll">
        <GuideModeSwitch copyMode />
        <section className="task-intro"><FileArrowDown size={28} weight="duotone" /><div><strong>导入外部攻略</strong><small>支持粘贴链接或上传攻略图片进行解析</small></div></section>
        <section className="form-card">
          <label><span>攻略链接</span><div className="link-field"><LinkSimple size={18} /><input value={linkValue} onChange={(event) => setLinkValue(event.target.value)} placeholder="粘贴小红书、公众号或网页链接" /></div></label>
          <button className="sample-link" type="button" onClick={() => setLinkValue("https://example.com/travel-guide")}>填入示例链接</button>
          <div className="import-divider"><span />或上传攻略图片<span /></div>
          <label className={uploadedGuidePreview ? "guide-image-upload has-preview" : "guide-image-upload"} htmlFor="guide-image-input">
            {uploadedGuidePreview ? <img src={uploadedGuidePreview} alt="待解析的攻略图片" /> : <ImageSquare size={25} weight="duotone" />}
            <span><strong>{uploadedGuideName || "上传攻略截图或长图"}</strong><small>支持 JPG、PNG，可识别地点、路线与文字</small></span>
            <UploadSimple size={20} weight="bold" />
          </label>
          <input id="guide-image-input" className="visually-hidden" type="file" accept="image/*" onChange={handleGuideImage} />
          <button className="primary-cta" type="button" onClick={() => {
            if (!linkValue.trim() && !uploadedGuideName) return notify("请粘贴链接或上传攻略图片");
            setImageParsed(Boolean(uploadedGuideName));
            setLinkParsed(true);
          }}><ClipboardText size={18} weight="fill" />导入并解析</button>
        </section>
        {linkParsed ? (
          <section className="result-placeholder">
            <div className="result-state"><Check size={18} weight="bold" /><strong>{imageParsed ? "图片解析完成，已转为可编辑结构" : "链接解析完成，已转为可编辑结构"}</strong></div>
            <div className="import-layout"><span /><span /><span /></div>
            <Skeleton rows={5} />
          </section>
        ) : <section className="empty-result-placeholder"><Skeleton rows={5} /></section>}
      </div>
      <TaskDock active="guide" onOpen={openXiaotuoTask} />
    </div>
  );

  const renderTickets = () => (
    <div className="ai-screen">
      <PhoneStatus />
      <ScreenHeader title="订票" subtitle="把条件一次说清" onBack={returnToXiaotuo} />
      <div className="ai-scroll task-page-scroll">
        <div className="mode-switch ticket-switch" role="tablist" aria-label="票务类型">
          <button type="button" className={ticketType === "flight" ? "active" : ""} onClick={() => { setTicketType("flight"); setTicketSearched(false); }}><AirplaneTilt size={19} />机票</button>
          <button type="button" className={ticketType === "train" ? "active" : ""} onClick={() => { setTicketType("train"); setTicketSearched(false); }}><Train size={19} />火车票</button>
        </div>
        <section className="route-card">
          <button type="button" onClick={() => notify("已打开出发地选择")}><small>出发地</small><strong>北京</strong></button>
          <span>{ticketType === "flight" ? <AirplaneTilt size={22} /> : <Train size={22} />}</span>
          <button type="button" onClick={() => notify("已打开目的地选择")}><small>目的地</small><strong>成都</strong></button>
          <button className="date-row" type="button" onClick={() => notify("已打开日期选择")}><CalendarDots size={18} /><span>选择出发日期</span><CaretRight size={17} /></button>
          <label><span>更多条件</span><textarea placeholder="例如：800元内、不要红眼、最好含行李" /></label>
          <button className="primary-cta" type="button" onClick={() => setTicketSearched(true)}><MagnifyingGlass size={18} />开始找票</button>
        </section>
        <section className={ticketSearched ? "ticket-result-list visible" : "ticket-result-list"}>
          {[1, 2, 3].map((item) => <button type="button" key={item} onClick={() => notify("已打开票务详情")}><span className="result-icon">{ticketType === "flight" ? <AirplaneTilt size={20} /> : <Train size={20} />}</span><Skeleton rows={3} /><CaretRight size={18} /></button>)}
        </section>
      </div>
      <TaskDock active="tickets" onOpen={openXiaotuoTask} />
    </div>
  );

  const toggleHotel = (id: number) => {
    setSelectedHotels((current) => {
      if (current.includes(id)) return current.filter((item) => item !== id);
      if (current.length >= 5) {
        notify("最多选择5家酒店");
        return current;
      }
      return [...current, id];
    });
  };

  const renderHotels = () => (
    <div className="ai-screen">
      <PhoneStatus />
      <ScreenHeader title="酒店PK" subtitle="选择酒店，横向比较" onBack={returnToXiaotuo} />
      <div className="ai-scroll task-page-scroll hotel-scroll">
        <button className="hotel-compare-entry" type="button" onClick={() => openView("hotel-select")}>
          <span className="hotel-compare-icons"><Buildings size={20} weight="fill" /><ArrowsLeftRight size={20} weight="bold" /><Buildings size={20} weight="fill" /></span>
          <span><strong>选择酒店开始PK</strong><small>从收藏、浏览记录或推荐中选2—5家</small></span>
          <CaretRight size={19} />
        </button>
        <section className="hotel-search-card">
          <label><span>目的地 / 位置</span><div><Buildings size={19} /><input placeholder="城市、商圈或景点" /></div></label>
          <button type="button" onClick={() => notify("已打开入住日期选择")}><CalendarDots size={18} /><span>入住日期 — 离店日期</span><CaretRight size={17} /></button>
          <label><span>酒店偏好</span><textarea placeholder="例如：亲子酒店、含早餐、1000元以内" /></label>
          <button className="primary-cta" type="button" onClick={() => setHotelSearched(true)}><MagnifyingGlass size={18} />搜索可PK酒店</button>
        </section>
        <section className={hotelSearched ? "hotel-result-list visible" : "hotel-result-list"}>
          <div className="list-caption"><strong>为你找到的酒店</strong><button type="button" onClick={() => openView("hotel-select")}>批量PK<CaretRight size={14} /></button></div>
          {hotelCatalog.slice(0, 3).map((hotel) => (
            <button type="button" key={hotel.id} className={selectedHotels.includes(hotel.id) ? "selected" : ""} onClick={() => toggleHotel(hotel.id)}>
              <HotelThumb hotel={hotel} />
              <span className="hotel-card-copy"><strong>{hotel.name}</strong><b>{hotel.rating}分 · {hotel.stars}</b><small>{hotel.area}</small><em>¥{hotel.price}起</em></span>
              <i>{selectedHotels.includes(hotel.id) && <Check size={14} weight="bold" />}</i>
            </button>
          ))}
        </section>
      </div>
      {hotelSearched && (
        <div className="compare-dock">
          <span>已选择 {selectedHotels.length} 家</span>
          <button type="button" className={selectedHotels.length >= 2 ? "ready" : ""} onClick={() => {
            if (selectedHotels.length < 2) return notify("请至少选择2家酒店");
            openView("hotel-compare");
          }}>去对比<CaretRight size={17} /></button>
        </div>
      )}
      <TaskDock active="hotels" onOpen={openXiaotuoTask} />
    </div>
  );

  const renderHotelSelect = () => {
    const currentHotelCatalog = hotelContext === "haidian" ? haidianHotelCatalog : hotelCatalog;
    const sourceHotels = hotelSource === "favorite"
      ? currentHotelCatalog
      : hotelSource === "browsed"
        ? [currentHotelCatalog[1], currentHotelCatalog[3], currentHotelCatalog[0], currentHotelCatalog[4], currentHotelCatalog[2]]
        : [currentHotelCatalog[2], currentHotelCatalog[0], currentHotelCatalog[1], currentHotelCatalog[3], currentHotelCatalog[4]];
    return (
      <div className="ai-screen">
        <PhoneStatus />
        <ScreenHeader title="选择要PK的酒店" subtitle="最多可选择5家" onBack={() => openView(hotelContext === "haidian" ? "hotel-landing" : "hotels")} />
        <div className="hotel-source-tabs" role="tablist" aria-label="酒店来源">
          {([
            ["favorite", "收藏的酒店"],
            ["browsed", "浏览的酒店"],
            ["recommended", "小驼推荐"],
          ] as Array<[HotelSource, string]>).map(([key, label]) => (
            <button type="button" role="tab" aria-selected={hotelSource === key} className={hotelSource === key ? "active" : ""} key={key} onClick={() => setHotelSource(key)}>{label}</button>
          ))}
        </div>
        <div className="ai-scroll hotel-select-scroll">
          <div className="hotel-select-note">选择2—5家酒店，小驼将按同一条件对比价格、位置与规则</div>
          <section className="hotel-select-list">
            {sourceHotels.map((hotel) => (
              <button type="button" key={hotel.id} className={selectedHotels.includes(hotel.id) ? "selected" : ""} onClick={() => toggleHotel(hotel.id)}>
                <i>{selectedHotels.includes(hotel.id) && <Check size={15} weight="bold" />}</i>
                <HotelThumb hotel={hotel} />
                <span className="hotel-card-copy"><strong>{hotel.name}</strong><b>{hotel.rating}分 · {hotel.stars}</b><small>{hotel.area}</small><em>¥{hotel.price}起</em></span>
              </button>
            ))}
          </section>
        </div>
        <div className="hotel-select-dock">
          <span>已选 <b>{selectedHotels.length}</b>/5 家酒店</span>
          <button type="button" className={selectedHotels.length >= 2 ? "ready" : ""} onClick={() => {
            if (selectedHotels.length < 2) return notify("请至少选择2家酒店");
            openView("hotel-compare");
          }}>帮我对比</button>
        </div>
      </div>
    );
  };

  const renderHotelCompare = () => {
    const currentHotelCatalog = hotelContext === "haidian" ? haidianHotelCatalog : hotelCatalog;
    const comparedHotels = (selectedHotels.length >= 2 ? selectedHotels : [1, 2])
      .map((id) => currentHotelCatalog.find((hotel) => hotel.id === id))
      .filter((hotel): hotel is Hotel => Boolean(hotel));
    const recommended = comparedHotels.reduce((best, hotel) => Number(hotel.rating) > Number(best.rating) ? hotel : best, comparedHotels[0]);
    const compareRows: Array<{ label: string; value: (hotel: Hotel) => string }> = [
      { label: "酒店等级", value: (hotel) => hotel.stars },
      { label: "预算参考", value: (hotel) => `¥${hotel.price}起` },
      { label: "评分", value: (hotel) => `${hotel.rating}/5` },
      { label: "交通位置", value: (hotel) => hotel.distance },
      { label: "早餐", value: (hotel) => hotel.breakfast },
      { label: "取消规则", value: (hotel) => hotel.cancellation },
      { label: "对比房型", value: (hotel) => hotel.room },
      { label: "适合人群", value: (hotel) => hotel.highlight },
    ];
    const gridStyle = { gridTemplateColumns: `82px repeat(${comparedHotels.length}, 148px)` };
    return (
      <div className="ai-screen">
        <PhoneStatus />
        <ScreenHeader title="酒店对比" subtitle={`${comparedHotels.length}家酒店 · 条件已对齐`} onBack={() => hotelContext === "haidian" ? openView("hotel-select") : returnToXiaotuo()} />
        <div className="ai-scroll hotel-compare-page">
          <section className="compare-recommendation">
            <Sparkle size={20} weight="fill" />
            <div><strong>小驼优先推荐：{recommended.name}</strong><p>综合评分、交通位置和预算参考后更均衡；你仍可横向查看全部差异。</p></div>
          </section>
          <div className="compare-matrix-scroll" aria-label="酒店对比表">
            <section className="compare-matrix">
              <div className="compare-matrix-head" style={gridStyle}>
                <b>对比项</b>
                {comparedHotels.map((hotel, index) => (
                  <button type="button" key={hotel.id} onClick={() => notify(`已打开${hotel.name}`)}>
                    <HotelThumb hotel={hotel} compare />
                    <strong>{hotel.name}</strong>
                    {index === 0 && <em>小驼推荐</em>}
                  </button>
                ))}
              </div>
              {compareRows.map((row) => (
                <div className="compare-matrix-row" style={gridStyle} key={row.label}>
                  <b>{row.label}</b>
                  {comparedHotels.map((hotel) => <span key={hotel.id}>{row.value(hotel)}</span>)}
                </div>
              ))}
            </section>
          </div>
          <p className="compare-disclaimer">以上为原型演示数据。实际价格、库存和取消规则需在预订时重新查询确认。</p>
          <button className="secondary-wide-button" type="button" onClick={() => openView("hotel-select")}>返回修改对比酒店</button>
        </div>
        <TaskDock active="hotels" onOpen={openXiaotuoTask} />
      </div>
    );
  };

  const renderPhone = () => {
    if (view === "home") return renderOriginalHome();
    if (view === "normal-search") return renderNormalSearch();
    if (view === "hotel-landing") return renderHotelLanding();
    if (view === "xiaotuo") return renderXiaotuoHub();
    if (view === "guide-create") return renderGuideCreate();
    if (view === "guide-copy") return renderGuideCopy();
    if (view === "tickets") return renderTickets();
    if (view === "hotels") return renderHotels();
    if (view === "hotel-select") return renderHotelSelect();
    return renderHotelCompare();
  };

  return (
    <main className={reviewOpen ? "prototype-shell review-open" : "prototype-shell review-closed"}>
      <aside className="review-panel" aria-hidden={!reviewOpen}>
        <div className="review-heading"><p>QUNAR · 问小驼</p><h1>交互流程</h1><span>点击左侧步骤可直接跳转</span></div>
        <nav className="flow-list" aria-label="原型流程">
          {flowSteps.map((step, index) => (
            <button type="button" key={step.view} className={activeFlow === step.view ? "current" : ""} onClick={() => {
              if (step.view === "hotel-compare" && selectedHotels.length < 2) setSelectedHotels([1, 2]);
              openView(step.view);
            }}>
              <b>{String(index + 1).padStart(2, "0")}</b>
              <span><strong>{step.title}</strong><small>{step.note}</small></span>
              <CaretRight size={17} />
            </button>
          ))}
        </nav>
        <a className="source-download" href="/qunar-wenxiaotuo-cursor.zip" download>
          <DownloadSimple size={18} weight="bold" />
          <span><strong>下载 Cursor 可编辑源码</strong><small>标准 React / TypeScript 项目</small></span>
        </a>
        <div className="review-note"><Sparkle size={18} weight="fill" /><p>手机内容固定为 iPhone 17 标准尺寸 393 × 852，不随左侧导航压缩。</p></div>
      </aside>
      <button className="review-toggle" type="button" onClick={() => setReviewOpen((current) => !current)} aria-label={reviewOpen ? "收起流程导航" : "展开流程导航"}>
        {reviewOpen ? <X size={19} weight="bold" /> : <SidebarSimple size={20} weight="bold" />}
        <span>{reviewOpen ? "收起" : "流程"}</span>
      </button>
      <section className="device-stage" aria-label="iPhone 17交互原型">
        <div className="device" data-testid="phone-frame">
          <div className="device-screen" data-testid="device-screen" data-phone-screen>
            <div className="screen-transition" key={`${view}-${appTab}`}>{renderPhone()}</div>
            {toast && <div className="toast" role="status">{toast}</div>}
          </div>
        </div>
        <div className="device-caption"><House size={14} />iPhone 17 · 393 × 852 · 1:1</div>
      </section>
    </main>
  );
}
