# Design QA

**Source visual truth**

- `/workspace/scratch/8178e32903ba/sites/qunar-wenxiaotuo/public/reference/qunar-home.jpg`
- Source pixels: 944 × 2048.
- Source app aspect ratio normalized to an iPhone 17 CSS viewport of 393 × 852.
- State: supplied Qunar home screen with the wide search entry, lower-page content and bottom navigation.

**Implementation evidence**

- Intended implementation viewport: 393 × 852 CSS pixels at deviceScaleFactor 1.
- The app sets `[data-phone-screen]` to a fixed 393 × 852 CSS box and does not scale it when the review navigation opens.
- Browser-rendered implementation screenshot: unavailable.
- Browser console evidence: unavailable.
- Primary interaction evidence: unavailable in the cloud browser.

**Findings**

- [P1] Browser-rendered visual comparison is blocked by the managed preview environment.
  Location: full prototype.
  Evidence: the supplied source screenshot was opened and inspected, but the managed preview service was unavailable before a browser tab could be opened. No valid implementation screenshot exists for a same-state comparison.
  Impact: fonts, exact overlay placement, source-logo crop, spacing, and interaction states cannot be signed off visually.
  Fix: open the rendered prototype at 393 × 852, capture `[data-phone-screen]`, compare it with the normalized source, test all primary flow clicks, and check the console.

**Required fidelity surfaces**

- Fonts and typography: specified in code, not browser-verified.
- Spacing and layout rhythm: fixed 393 × 852 geometry is implemented, not browser-verified.
- Colors and visual tokens: Qunar cyan, white cards, and neutral backgrounds are specified, not browser-verified.
- Image quality and asset fidelity: supplied Qunar screenshots remain the page background; the Qunar camel mark is now a standalone 48 × 44 image rendered with `object-fit: contain`, not browser-verified.
- Copy and content: new flow labels match the requested scope; rendered wrapping is not browser-verified.

**Primary interactions intended for verification**

- Collapse and expand the review navigation without resizing the phone viewport.
- Open the unified search gateway from the wide home search box.
- Switch between “搜索”和“问小驼” and exercise both paths.
- Switch between “做攻略” and “抄攻略”.
- Enter an external link and complete the import/parse state.
- Open “订票”, switch between flight and train, and reveal result placeholders.
- Open “找酒店”, select two hotels, and enter the comparison placeholder page.
- Switch all five original Qunar bottom tabs and click the retained-page hotspots.

**Comparison history**

- No valid visual-comparison iteration could be completed because browser-rendered evidence was unavailable.

**Implementation checklist**

- Capture the 393 × 852 implementation screen in the managed browser.
- Verify the wide search entry precisely replaces the old split search/“足迹收藏” area.
- Verify every primary click path and browser console.
- Fix any P0/P1/P2 mismatch and repeat the same-state comparison.

**Follow-up polish**

- Re-check the home search hotspot alignment and both gateway modes when browser evidence is available.

final result: blocked
